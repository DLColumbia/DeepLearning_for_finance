# DeepLearning_for_finance

NB: if first program on jupyter notebook does not work try with the following line of code (one works for Windows and some MACs only)

with open('IBB_holdings.csv', 'r') as csvfile: #WINDOWS and some MACs

/OR/

with open('IBB_holdings.csv', 'r', encoding='mac_roman', newline='') as csvfile:  #MAC

Make sure you have the following librairies : os, csv, matplotlib, numpy, pandas_datareader, datetime, pandas
